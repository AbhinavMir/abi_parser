from abi_parser import ContractABI

abi = ContractABI('tests/uniswap.sol/IUniswapV2Router.json')

assert abi.name == 'IUniswapV2Router'
assert abi.file_path == 'tests/uniswap.sol/IUniswapV2Router.json'
assert abi.constructor is None
assert abi.fallback is None
assert abi.receive is None
print(abi.get_function_by_name('swapExactTokensForTokens'))
