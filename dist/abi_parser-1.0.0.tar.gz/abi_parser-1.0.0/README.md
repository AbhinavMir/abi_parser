### abi_parser

A simple way to parse your ABIs in Python.

```python
from abi_parser import ContractABI
abi = ContractABI('<PATH TO ABI JSON'>)

# name
name = abi.name

# functions
functions = abi.functions

# events
events = abi.events
```
